#Projeto Final - Karina Regina de Souza e Vitória Silva Alves

#Introdução
Nome = input("Por favor insira o seu nome aqui: ")
print("\nOlá" , Nome,"Seja bem-vindo ao jogo! É hora do show! Preparado?\n")

#Função - Resposta
Resposta = input("Insira 'sim' ou 'não'\n")

if(Resposta == "sim" and ("não")):
 print("Que os jogos começem! Boa sorte!")
  
elif(Resposta == "Sim" and ("Não")):
 print("Que os jogos começem! Boa sorte!")
else:
  print("Que pena..Até logo!")

#Palavra secreta que podem ser alterada
palavra = "flor"

#Ajuda na seleção
acerto = ["flor"]
erros = 0
  #Início do jogo
print("\nSua palavra foi selecionada, boa sorte para acertar")

print("\nVocê tem 6 chances, se errar, fim de jogo")
print("\n ************************************************")
print("\n _*_*_*_" , "\nSua palavra tem 4 letras.")

#Palavra flor 

#Primeira letra
#repetição
while (erros < 6): 
 tentativas = input("\nInsira uma letra: ")

 erros = erros + 1

 if (tentativas in palavra and (tentativas == "f")):
  print("\nParábens! Já acertou uma!")
  print("\n f*_*_*_")

 elif (tentativas in palavra and (tentativas == "l")):
  print("\nParábens! Já acertou uma!")
  print("\n _*l*_*_")

 elif (tentativas in palavra and (tentativas == "o")):
  print("\nParábens! Já acertou uma!")
  print("\n _*_*o*_")

 elif (tentativas in palavra and (tentativas == "r")):
  print("\nParábens! Já acertou uma!")
  print("\n _*_*_*r")

 elif (tentativas in palavra or (tentativas == "F")):
  print("\nParábens! Já acertou uma!")
  print("\n f*_*_*_")

 elif (tentativas in palavra or (tentativas == "L")):
  print("\nParábens! Já acertou uma!")
  print("\n _*l*_*_")

 elif (tentativas in palavra or (tentativas == "O")):
  print("\nParábens! Já acertou uma!")
  print("\n _*_*o*_")

 elif (tentativas in palavra or (tentativas == "R")):
  print("\nParábens! Já acertou uma!")
  print("\n _*_*_*r")

 else:
  print("Você errou! Você tem: " , erros,"erro")

 while tentativas == palavra:
  len(acerto)
  if(tentativas == acerto):
    print("Parabéns você venceu! Que sorte a sua!")
 #próximas letras
    
#função erros
 if (erros == 6):
  print("Você perdeu o jogo! Cara, mais sorte na próxima vez, tu precisa.")
